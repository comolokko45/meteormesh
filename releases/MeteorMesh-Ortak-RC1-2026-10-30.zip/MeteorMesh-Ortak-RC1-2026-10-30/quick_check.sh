#!/usr/bin/env bash
set -euo pipefail
if [[ "$(id -u)" == 0 ]]; then echo 'Refusing root'; exit 2; fi
cd "$(dirname "${BASH_SOURCE[0]}")/MeteorHub"
python3 -B mm01_readonly_preflight.py
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest -q test_lab_http_adapter test_mm03_merge
printf '%s\n' 'RC1_STAGING_SMOKE_OK; NO_PRODUCTION_ACTIVATION'
